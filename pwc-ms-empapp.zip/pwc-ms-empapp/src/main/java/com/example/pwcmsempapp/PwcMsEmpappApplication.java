package com.example.pwcmsempapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwcMsEmpappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwcMsEmpappApplication.class, args);
	}

}
