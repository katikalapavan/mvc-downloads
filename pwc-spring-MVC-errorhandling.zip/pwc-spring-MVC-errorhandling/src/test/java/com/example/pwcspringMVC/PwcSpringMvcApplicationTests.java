package com.example.pwcspringMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcSpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
