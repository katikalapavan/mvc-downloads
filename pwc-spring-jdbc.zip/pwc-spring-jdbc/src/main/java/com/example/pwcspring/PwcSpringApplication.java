package com.example.pwcspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwcSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwcSpringApplication.class, args);
	}

}
