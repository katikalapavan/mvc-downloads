package com.example.pwcspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
