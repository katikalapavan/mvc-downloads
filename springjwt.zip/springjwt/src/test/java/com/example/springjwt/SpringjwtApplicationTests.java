package com.example.springjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
